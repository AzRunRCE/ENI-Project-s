package fr.eni.android.demo_m05s03_database;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import java.util.List;

import fr.eni.android.demo_m05s03_database.bo.Personne;
import fr.eni.android.demo_m05s03_database.dao.PersonneDao;

public class MainActivity extends AppCompatActivity {

    private final static String TAG = "MyLOG [IHM Controleur]";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    @Override
    protected void onResume() {
        super.onResume();

        PersonneDao dao = new PersonneDao(this);

        Personne p1 = new Personne("GOBIN", "Stéphane");
        long id = dao.insert(p1);
        String feedBack = "Id de l'insertion : " + id;
        Toast.makeText(this, feedBack, Toast.LENGTH_LONG).show();
        Log.i(TAG, feedBack);

//Manipulation de la Base de Données…

        /*Personne p2 = dao.get(2);
        p2.setNom("ZILLA");
        p2.setPrenom("Gad");
        dao.update(p2);*/

/*        Personne p3 = dao.get(3);
        dao.delete(p3);*/


       List<Personne> listeDePersonnes = dao.get(); // Select All
        // Parcours de la collection de Personnes
        for(Personne unePersonne : listeDePersonnes) {
            Log.i(TAG, unePersonne.toString());
        }

    }

}
