package fr.eni.android.demo_m05s03_database.dao;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

import fr.eni.android.demo_m05s03_database.bo.Personne;
import fr.eni.android.demo_m05s03_database.contract.PersonneContract;

public class PersonneDao {

    private final static String TAG = "MyLOG";

    private BddHelper helper; // Manager de la Base (DDL)
    private SQLiteDatabase db; // Exploiter la Base (DML)

    public PersonneDao(Context context) {
        helper = new BddHelper(context);
        db = helper.getWritableDatabase();
    }

    // Création d'un Enregistrement : INSERT INTO / SQL
    public long insert(Personne unePersonne) {
        Log.i(TAG,"PersonneDao.insert");
        ContentValues cv = new ContentValues();
        cv.put(PersonneContract.COL_LAST_NAME, unePersonne.getNom());
        cv.put(PersonneContract.COL_FIRST_NAME, unePersonne.getPrenom());

        long reponse = db.insert(PersonneContract.TABLE_NAME, null, cv);
        unePersonne.setId(reponse);
        return reponse;
    }

    // Modification d'un Enregistrement : UPDATE/ SQL
    public boolean update(Personne unePersonne) {
        Log.i(TAG,"PersonneDao.update");
        boolean reponse = false;
        if (unePersonne.getId() > 0) {
            ContentValues cv = new ContentValues();
            cv.put(PersonneContract.COL_LAST_NAME, unePersonne.getNom());
            cv.put(PersonneContract.COL_FIRST_NAME, unePersonne.getPrenom());

            reponse = db.update(PersonneContract.TABLE_NAME, cv,
                    PersonneContract.COL_ID + "=?",
                    new String[]{String.valueOf(unePersonne.getId())}) > 0;
        }

        return reponse;
    }

    // Suppression d'un Enregistrement : DELETE/ SQL
    public boolean delete(Personne unePersonne) {
        Log.i(TAG,"PersonneDao.delete");
        boolean reponse = false;
        if (unePersonne.getId() > 0) {
            reponse = db.delete(PersonneContract.TABLE_NAME, PersonneContract.COL_ID + "=?",
                    new String[]{String.valueOf(unePersonne.getId())}) > 0;
        }

        return reponse;
    }

    // Récupération d'un enregistrement
    public Personne get(long id){
        Log.i(TAG,"PersonneDao.get");
        Personne reponse = null;

        //SQL : SELECT * FROM personnes WHERE id=?
        Cursor cursor = db.query(PersonneContract.TABLE_NAME, //FROM
                new String[]{PersonneContract.COL_ID,
                             PersonneContract.COL_LAST_NAME,
                             PersonneContract.COL_FIRST_NAME}, // SELECT
                PersonneContract.COL_ID + "=?", // WHERE
                new String[]{String.valueOf(id)},null,null,null
                );
        if(cursor.moveToNext()) {
            reponse = new Personne(
                    cursor.getLong(cursor.getColumnIndex(PersonneContract.COL_ID)),
                    cursor.getString(cursor.getColumnIndex(PersonneContract.COL_LAST_NAME)),
                    cursor.getString(cursor.getColumnIndex(PersonneContract.COL_FIRST_NAME))
            );

        }

        return reponse;
    }

    // Récupération de tous les enregistrements
    public List<Personne> get(){
        Log.i(TAG,"PersonneDao.getAll");
        List<Personne> reponse = new ArrayList<>();

        //SQL : SELECT * FROM personnes
        Cursor cursor = db.query(PersonneContract.TABLE_NAME, //FROM
                new String[]{PersonneContract.COL_ID,
                        PersonneContract.COL_LAST_NAME,
                        PersonneContract.COL_FIRST_NAME}, // SELECT
                null, // WHERE
                null,null,null,null
        );

        while(cursor.moveToNext()) {
            Personne uneNouvellePersonne = new Personne(
                    cursor.getLong(cursor.getColumnIndex(PersonneContract.COL_ID)),
                    cursor.getString(cursor.getColumnIndex(PersonneContract.COL_LAST_NAME)),
                    cursor.getString(cursor.getColumnIndex(PersonneContract.COL_FIRST_NAME))
            );
            reponse.add(uneNouvellePersonne);
        }

        return reponse;
    }


}
