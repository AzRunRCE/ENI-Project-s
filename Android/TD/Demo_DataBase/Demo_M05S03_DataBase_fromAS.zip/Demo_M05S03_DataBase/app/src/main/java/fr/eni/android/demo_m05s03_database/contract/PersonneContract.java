package fr.eni.android.demo_m05s03_database.contract;

public interface PersonneContract {

    public static final String TABLE_NAME = "personnes";

    public static final String COL_ID = "id";
    public static final String COL_LAST_NAME = "last_name";
    public static final String COL_FIRST_NAME = "first_name";

    public static final String CREATE_TABLE = String.format("CREATE TABLE %s ("+
                    "%s INTEGER PRIMARY KEY AUTOINCREMENT,"+
                    "%s TEXT, %s TEXT);"
            ,TABLE_NAME, COL_ID, COL_LAST_NAME, COL_FIRST_NAME);
    public static final String DROP_TABLE = String.format("DROP TABLE %s;",TABLE_NAME);





}
