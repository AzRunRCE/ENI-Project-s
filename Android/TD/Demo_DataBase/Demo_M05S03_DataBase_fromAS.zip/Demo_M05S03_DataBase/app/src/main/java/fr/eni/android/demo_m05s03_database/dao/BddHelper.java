package fr.eni.android.demo_m05s03_database.dao;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import fr.eni.android.demo_m05s03_database.contract.PersonneContract;

// Manager de la Base de Données
public class BddHelper extends SQLiteOpenHelper {

    private final static int VERSION = 1;
    private final static String DB_FILENAME = "demonstration.db";
    private static final String TAG = "MyLOG";

    public BddHelper(Context context) {
        super(context, DB_FILENAME, null, VERSION);
        Log.i(TAG,"BddHelper.constructor()");
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        Log.i(TAG,"BddHelper.onCreate()");
        db.execSQL(PersonneContract.CREATE_TABLE);
        // Création d'un fichier DB_FILENAME avec son journal
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        Log.i(TAG,"BddHelper.onUpgrade()");
        db.execSQL(PersonneContract.DROP_TABLE);
        onCreate(db);
        /*switch (oldVersion) {
            case 1 :
                Log.i(TAG,"Delta SQL version 1 -> 2");
            case 2:
                Log.i(TAG,"Delta SQL version 2 -> 3");
            case 3:
                Log.i(TAG,"Delta SQL version 3 -> 4");
                break;
            default:
                Log.i(TAG,"switch.default");
        }*/
    }

    @Override
    public void onDowngrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        Log.i(TAG,"BddHelper.onDowngrade()");
        onUpgrade(db, oldVersion, newVersion);
    }
}
